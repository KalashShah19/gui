﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace CIE_3_PRACTICE
{
    public partial class Form1 : Form
    {
        SqlConnection con = new SqlConnection("Data Source=DESKTOP-K4C46LA\\SQLEXPRESS;Initial Catalog=Student;Integrated Security=True");
        SqlCommand cmd=new SqlCommand();

        public Form1()
        {
            InitializeComponent();
        }

        private void btnInsert_Click(object sender, EventArgs e)
        {

        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {

        }

        private void btnDelete_Click(object sender, EventArgs e)
        {

        }

        private void btnSearch_Click(object sender, EventArgs e)
        {

        }

        private void rbInsert_CheckedChanged(object sender, EventArgs e)
        {
            tbID.Enabled = false;
            tbName.Enabled = true;
            gbGender.Enabled = true;
            ddCity.Enabled = true;
            ddCountry.Enabled = true;
            ddState.Enabled = true;
            inpDate.Enabled = true;
            tbContactNo.Enabled = true;
            gbLang.Enabled = true;


        }
    }
}
